package com.chan.myportfolio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;

public class JsActivity extends AppCompatActivity {
    private WebView mWebView;
//    private Button mbutton01;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_js);

//        this.mbutton01 = (Button)findViewById(R.id.button_01);
//        this.mbutton01.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View view) {
//                mWebView.loadUrl("javascript:document.getElementById('title').InnerHTML='왜눌렀어..';");
//            }
//        });
        this.mWebView = (WebView)findViewById(R.id.webview);
        this.mWebView.setWebViewClient(new MyWebViewClient());
        this.mWebView.setWebChromeClient(new MyWebChormeClient());
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.addJavascriptInterface(new MYJavascript(),"android");
        this.mWebView.loadUrl("file:///android_asset/www/index.html");
    }


    class MYJavascript {
        @JavascriptInterface
        public void jsOnClick(){
            Toast.makeText(JsActivity.this,"안드로이드에서 눌렀네",Toast.LENGTH_SHORT).show();
        }
    }

    class MyWebViewClient extends WebViewClient{

    }

    class MyWebChormeClient extends WebChromeClient{

    }


}
