package com.chan.myportfolio;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.chan.myportfolio.fragments.HomeFragment;
import com.chan.myportfolio.fragments.LikeFragment;
import com.chan.myportfolio.fragments.ProfileFragment;
import com.chan.myportfolio.fragments.SearchFragment;

public class BabyinstaActivity extends AppCompatActivity {

    private final int FRAGMENT_HOME = 1;
    private final int FRAGMENT_SEARCH = 2;
    private final int FRAGMENT_WRITE = 3;
    private final int FRAGMENT_LIKE = 4;
    private final int FRAGMENT_PROFILE = 5;

    private ImageView mImageViewHome;
    private ImageView mImageViewSearch;
    private ImageView mImageViewWrite;
    private ImageView mImageViewLike;
    private ImageView mImageViewProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_babyinsta);
        this.mImageViewHome =(ImageView)findViewById(R.id.btn_home);
        this.mImageViewSearch =(ImageView)findViewById(R.id.btn_search);
        this.mImageViewWrite =(ImageView)findViewById(R.id.btn_write);
        this.mImageViewLike =(ImageView)findViewById(R.id.btn_like);
        this.mImageViewProfile =(ImageView)findViewById(R.id.btn_profile);

        showFragment(FRAGMENT_HOME);

    }
    public void onButtonClick(View view){
        switch (view.getId()){
            case R.id.btn_home:
                showFragment(FRAGMENT_HOME);
                break;
            case R.id.btn_write:
                showFragment(FRAGMENT_WRITE);
                break;
            case R.id.btn_like:
                showFragment(FRAGMENT_LIKE);
                break;
            case R.id.btn_profile:
                showFragment(FRAGMENT_PROFILE);
                break;
            case R.id.btn_search:
                showFragment(FRAGMENT_SEARCH);
                break;

        }
    }

    private void changeButtonImages(int fragment_id){
        this.mImageViewHome.setImageResource(R.drawable.btn_home);
        this.mImageViewSearch.setImageResource(R.drawable.btn_search);
        this.mImageViewWrite.setImageResource(R.drawable.btn_write);
        this.mImageViewProfile.setImageResource(R.drawable.btn_profile);
        this.mImageViewLike.setImageResource(R.drawable.btn_like);
        switch (fragment_id){
            case FRAGMENT_HOME:
                this.mImageViewHome.setImageResource(R.drawable.btn_home_selected);
                break;
            case FRAGMENT_SEARCH:
                this.mImageViewSearch.setImageResource(R.drawable.btn_search_selected);
                break;
            case FRAGMENT_WRITE:
                this.mImageViewWrite.setImageResource(R.drawable.btn_write_selected);
                break;
            case FRAGMENT_LIKE:
                this.mImageViewLike.setImageResource(R.drawable.btn_like_selected);
                break;
            case FRAGMENT_PROFILE:
                this.mImageViewProfile.setImageResource(R.drawable.btn_profile_selected);
                break;
        }
    }
    private void showFragment(int fragment_id){
        FragmentTransaction tran = getSupportFragmentManager().beginTransaction();
        changeButtonImages(fragment_id);
        switch (fragment_id){
            case FRAGMENT_HOME:
                HomeFragment homeFragment = HomeFragment.newInstance("","");
                tran.replace(R.id.fragment_container, homeFragment);
                break;
            case FRAGMENT_SEARCH:
                SearchFragment searchFrament = SearchFragment.newInstance("","");
                tran.replace(R.id.fragment_container, searchFrament);
                break;
            case FRAGMENT_LIKE:
                LikeFragment likeFragment = LikeFragment.newInstance("","");
                tran.replace(R.id.fragment_container, likeFragment);
                break;
            case FRAGMENT_PROFILE:
                ProfileFragment profileFragment = ProfileFragment.newInstance("","");
                tran.replace(R.id.fragment_container, profileFragment);
                break;
        }
        tran.commit();
    }
}
