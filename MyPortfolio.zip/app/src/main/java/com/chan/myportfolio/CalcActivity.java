package com.chan.myportfolio;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewStructure;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class CalcActivity extends AppCompatActivity {

    private TextView mTextView;
    private double mStoredValue = 0;
    private String mOperater = "+";
    private boolean mClearFlag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calc);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.mTextView = (TextView)findViewById(R.id.textView);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onButtonClick(View view) {
        switch (view.getId()) {
            case R.id.button_pm:
                togglePlus();
                break;
            case R.id.button_p:
                break;
            case R.id.button_plus:
            case R.id.button_sub:
            case R.id.button_div:
            case R.id.button_mtp:
            case R.id.button_eq:
                setOperater(view);
                break;
            case R.id.button_0:
            case R.id.button_1:
            case R.id.button_2:
            case R.id.button_3:
            case R.id.button_4:
            case R.id.button_5:
            case R.id.button_6:
            case R.id.button_7:
            case R.id.button_8:
            case R.id.button_9:
            case R.id.button_dt:
                setDisplay(((Button)view).getText().toString());
                break;
            case R.id.button_ac:
                clearData();
                break;
        }
    }

    private void togglePlus() {
        String str = this.mTextView.getText().toString();
        if(str.startsWith("-")){
            str = str.substring(1);
        }else{
            str = "-"+str;
        }
        this.mTextView.setText(str);
    }

    private String fixDataType(String str) {
        DecimalFormat df = new DecimalFormat("#,##0.########");
        if (Double.parseDouble(str) - (int)Double.parseDouble(str) == 0.0){
            return df.format((int)Double.parseDouble(str));
        } else {
            return df.format(Double.parseDouble(str));
        }
    }

    private  void clearData() {
        this.mTextView.setText("0");
        this.mOperater = "+";
        this.mStoredValue = 0;
        this.mClearFlag = false;
    }

    private void setOperater(View view) {
        double lastValue = Double.parseDouble(this.mTextView.getText().toString());
        switch (this.mOperater){
            case "+":
                this.mStoredValue += lastValue;
                break;
            case "-":
                this.mStoredValue -= lastValue;
            case "X":
                this.mStoredValue *= lastValue;
                break;
            case "÷":
                this.mStoredValue /= lastValue;
                break;
            case "=":
                this.mStoredValue = lastValue;
                break;
        }
        String strTemp = fixDataType(String.valueOf(this.mStoredValue));
        this.mTextView.setText(strTemp);
        this.mTextView.setText(strTemp);
        this.mOperater = ((Button)view).getText().toString();
        this.mClearFlag = true;
    }

    private void setDisplay(String strNum) {
        if(this.mClearFlag){
            this.mTextView.setText("0");
            this.mClearFlag = false;
        }
        String strPrev = this.mTextView.getText().toString();
        if (strNum.equals(".") && strPrev.indexOf(".") != -1)return;
        if (!strNum.equals(".") && strPrev.equals("0"))strPrev = "";
        this.mTextView.setText(strPrev + strNum);
    }
    private void makePercent(){
        String str = this.mTextView.getText().toString();
        str = str.replace(",","");
        double x = Double.parseDouble(str)/100;
        str = fixDataType(String.valueOf(x));
        this.mTextView.setText(str);
    }
}