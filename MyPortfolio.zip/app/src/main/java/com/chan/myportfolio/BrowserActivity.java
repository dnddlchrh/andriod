package com.chan.myportfolio;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class BrowserActivity extends AppCompatActivity {

    private WebView mWebView;
    private TextView mEditViewUrl;
    private ProgressBar mProgressBar;
    private long lastBackPressed = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);
        initWebView();
    }
    private void initWebView(){
        this.mProgressBar = (ProgressBar)findViewById(R.id.progressBar);
        this.mEditViewUrl = (EditText)findViewById(R.id.editText);
        this.mEditViewUrl.setOnKeyListener(new View.OnKeyListener(){

            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if(keyEvent.getAction()==KeyEvent.ACTION_DOWN && i==KeyEvent.KEYCODE_ENTER){
                    loadUrl();
                    return true;
                }
                return false;
            }
        });
        this.mWebView = (WebView)findViewById(R.id.webview);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.setWebViewClient(new MyWebViewClient());
        this.mWebView.setWebChromeClient(new WebChromeClient());
        this.mWebView.loadUrl("https://www.naver.com/");
    }
    
    private void loadUrl(){
        String url = mEditViewUrl.getText().toString();
        if(!url.toLowerCase().startsWith("http")){
            url = "http://"+url;
        }
        this.mWebView.loadUrl(url);
        InputMethodManager imm = (InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(this.mEditViewUrl.getWindowToken(),0);
    }

    private void goBack(){
        if(this.mWebView.canGoBack()){
            this.mWebView.goBack();
        }else{
            Toast.makeText(this,"더 이상 뒤로 갈 수 없습니다",Toast.LENGTH_SHORT).show();
        }
    }
    private void goForward(){
        if(this.mWebView.canGoForward()){
            this.mWebView.goForward();
        }else{
            Toast.makeText(this,"더 이상 앞으로 갈 수 없습니다",Toast.LENGTH_SHORT).show();
        }
    }
    public void onButtonClick(View view){
        switch (view.getId()){
            case R.id.button_go:
                loadUrl();
                break;
            case R.id.button_prev:
                goBack();
                break;
            case R.id.button_next:
                goForward();
                break;
        }
    }
    public void onBackPressed() {
        if(mWebView.canGoBack()){
            this.mWebView.goBack();
        }else {
            if (System.currentTimeMillis()- lastBackPressed > 1000){
                Toast.makeText(this,"한번 더 누르시면 종료됩니다",Toast.LENGTH_SHORT).show();
                lastBackPressed = System.currentTimeMillis();
            }else{
                finish();
                System.exit(0);
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        }
    }


    private class MyWebViewClient extends WebViewClient{
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            mEditViewUrl.setText(url);
            mProgressBar.setProgress(0);
            mProgressBar.setVisibility(View.VISIBLE);
        }

        public void onPageFinished(WebView view, String url){
            super.onPageFinished(view,url);
            mProgressBar.setProgress(100);
            mProgressBar.setVisibility(View.GONE);
        }
    }
}